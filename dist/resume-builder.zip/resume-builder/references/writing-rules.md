# Writing rules

Each rule has a reason, so you can judge edge cases.

## Truth
- **Never invent, round up or guess.** A resume is a list of things the person will be asked about. Anything they cannot explain costs them the interview. If a number is missing, write the result in words or leave it out.
- **Skills need proof.** List a tool only if the person is comfortable with it or a project proves it. Use brackets for "(learning)". Tools they only saw in a course go in coursework, not skills.
- **Do not copy claims from old resumes or from the posting.** Old resumes often overstate; postings list what the employer wants, not what the person has.
- If a number depends on an assumption (a scenario, a simulation), say so in the bullet ("modelled", "simulated"). Never present a scenario as a result.

## Bullets
- One sentence each: **action verb + what you did + result**, joined with words like "finding", "cutting", "raising", "showing", "identifying".
  - Good: "Built a staff schedule from hourly sales data, cutting labour costs 10% while service times held steady."
  - Weak: "Responsible for scheduling staff."
- Start each bullet with a different verb. Repeated openings read as a template.
- 3 to 5 bullets for the main job, 2 to 3 for older ones, 2 to 3 per project.
- Numbers only when real. Use "to" for ranges ("May 2020 to Jun 2023").
- Plain verbs: built, ran, tracked, cut, raised, wrote, tested, trained, planned, compared.
- Do not start every line with "I". The resume has no "I" except where a short clause on AI use needs it (see ai-disclosure.md).

## Summary (optional but useful)
- Maximum 3 lines. Who they are, one proof point, what they want ("Seeking a Summer 2027 data co-op").
- Mirror the posting's role name once. No adjectives like "motivated" or "hard-working".

## Skills section
- Group with plain labels: Tools, Data, Business, Languages. Put the posting's top tools first (only if true).
- Use the posting's exact spelling for a skill the person really has ("Data Visualization", not "charts"), because ATS software matches words.

## Banned words and marks
Remove: spearheaded, leveraged, utilized, synergy, pivotal, intricate, realm, showcasing, delve, robust, seamless, dynamic, results-driven, passionate, proven track record, detail-oriented, fast-paced, team player, go-getter, hard-working.
Why: they are empty, they read as machine-written, and they push out concrete facts.
Also: **no em dashes or en dashes** (use "to", a comma or a new sentence), no emoji, no icons.

## Formatting for ATS
- One column. No tables, text boxes, images, headers, footers, skill bars or graphics.
- Standard headings, in this order for students: SUMMARY, EDUCATION, SKILLS, EXPERIENCE, PROJECTS. For experienced people: SUMMARY, EXPERIENCE, SKILLS, PROJECTS, EDUCATION.
- Contact line in the body (not a header). Plain-text URLs.
- Dates like "May 2020 to Jun 2023". Location as "City, Country".
- A real-text PDF (not a picture). File name: `First_Last_Resume_Company.pdf`, at most 50 characters.
- Leave GPA, photo, date of birth, marital status and full street address off unless a posting or local custom requires them.

## Review pass before showing anything
Read it as a skeptical recruiter: Is every number traceable to `profile.md`? Does any bullet start the same way as the one above? Would the person be comfortable explaining each line for two minutes? Any word from the banned list?

## Thin profiles: no padding
If the person has little to show, a short honest resume beats a padded one. Do not add vague detail the person did not state ("on the routine", "fixed and tested", "worked closely with the team"). Every phrase should trace to something they said. If a bullet has no result, ask one follow-up question instead of inventing one. A resume that fills two thirds of a page is fine.

## Hedged numbers
If the person says "about 12%", write "about 12%" and keep it identical in the resume, letter and prep sheet. Never convert it to a rounder or bigger number.

## Soft-skill keywords
Words like "stakeholder communication" or "teamwork" go on only if the person gave you an example. Otherwise show them through a bullet or leave them in `needs-input.md`. Do not ask leading questions ("Are you okay at stakeholder communication?"); ask for a story ("Tell me about a time you explained something to a manager").

## File names
- Master PDF: `First_Last_Resume.pdf`
- Per job: `First_Last_Resume_<Company>.pdf`, `First_Last_CoverLetter_<Company>.pdf` (the `.md` sources and `prep.md` may keep short names)
- At most 50 characters, no spaces.

## Lessons from a real co-op search
These come from one student's live job search, where 60+ tailored packages were built and checked. They are soft rules: explain once, then follow the person's choice.
- **One-line header.** City, phone, email, LinkedIn on a single line. It saves two lines for content and keeps the resume and the letter header identical.
- **One project with a number from the person's own data.** A project that tracks something real (applications, budget, a model) and states a measured result beats three vague ones. Write what was measured and over what period; mark scenarios as "modelled". If the number is not in `profile.md`, ask for it.
- **Tools the person lacks stay out.** When a posting names a tool the person has not used (Power Query, VBA, a CRM, an ERP), list it in `needs-input.md` and the prep sheet as a gap with a plain way to say so in an interview. Never add it to Skills "to pass the filter".
- **Use the email the person chooses on applications** (often a school address) and keep any other address private. Ask once, then use it everywhere, resume and letter alike.
- **Company numbers need a source.** A funding round, revenue, a percentage: use one in a letter only if the person supplied it or you cite a dated source and flag it in `needs-input.md`. If unsure, write the letter without the figure; a sentence about what the company does is safer than a number that may be wrong.
- **Check the posting is still open** before building a package, and look for the start date and term. If neither is stated, build anyway but flag "check the term" in `needs-input.md` so the person asks the employer before applying.
- **Never send for them.** The builder prepares files. The person reviews, submits and sends every message themselves.
